import { NamePipe } from './name.pipe';

describe('NamePipe', () => {

  let pipe ;
  beforeEach(() => {
    pipe = new NamePipe();
  });
  it('create an instance', () => {
    
    expect(pipe).toBeTruthy();
  });

  it('should return prefix as HELLO', () => {
    
    expect(pipe.transform('samik')).toContain("HELLO");
  });


});
