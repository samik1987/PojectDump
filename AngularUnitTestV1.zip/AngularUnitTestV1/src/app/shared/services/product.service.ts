import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';

import {  throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export class Product {
  public Id : number ;
  public  Title : string;
  public  Cost : number;
  public  Quantity : number;
  public TotalCost : number;
}


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  

  BASE_URL : string = "http://localhost:6813/api/";
  
  
  constructor(private httpClient: HttpClient) {   
  
    
     }

     GetProductService()
     {
       debugger;
      return this.httpClient.get( this.BASE_URL +'Products/GetAllGeneralProducts').pipe(catchError(this.handleError));
     }

     AddProductService(_input:Product)
     {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          
        })
      }
      return this.httpClient.post<any>( this.BASE_URL +'Products/AddGeneralProduct', _input,httpOptions).pipe(catchError(this.handleError));
     }

     UpdateProductService(_input:Product)
     {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          
        })
      }
      return this.httpClient.post<any>( this.BASE_URL +'Products/UpdateGeneralProduct', _input,httpOptions).pipe(catchError(this.handleError));
     }

     DeleteProductService(id:number)
     {

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'id':id.toString()        
        })
        
      }

      const  params = new  HttpParams().set('pid', id.toString());
      
      return this.httpClient.post<any>( this.BASE_URL +'Products/RemoveGeneralProduct',null, { params }).pipe(catchError(this.handleError));

     }

     handleError(error: HttpErrorResponse) {
      let errorMessage = 'Unknown error!';
      if (error.error instanceof ErrorEvent) {
        // Client-side errors
        errorMessage = `Error: ${error.error.message}`;
      } else {
        // Server-side errors
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      window.alert(errorMessage);
      return throwError(errorMessage);
    }
}
