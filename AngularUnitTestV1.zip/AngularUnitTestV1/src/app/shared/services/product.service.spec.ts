import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { Product, ProductService } from './product.service';

describe('ProductService', () => {
  let http: jasmine.SpyObj<HttpClient>;
  let service: ProductService;
  let data : Product[];

  beforeEach(() => {
    http = jasmine.createSpyObj('HttpClient',['get','post']);
   
    TestBed.configureTestingModule({
      providers: [
        ProductService,
        {
          provide:HttpClient ,useValue : http
        }
      ]
    });
    service = TestBed.inject(ProductService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('service should return data', () => {
    const _products : Product[] = [
      {
      Id : 1 ,
      Title : "Cycle",
      Cost : 2,
      Quantity : 3,
      TotalCost : 6
      },
      {
        Id : 2 ,
        Title : "Truck",
        Cost : 2,
        Quantity : 4,
        TotalCost : 8
        },
      
  ];
     http.get.and.returnValues(of(_products));
   
      service.GetProductService().subscribe((result : Product[] )=>
      {  
         expect(result.length>0).toEqual(true);
      });


  });

  it('service should add data', () => {
    const _product : Product =
      {
      Id : 1 ,
      Title : "Cycle",
      Cost : 2,
      Quantity : 3,
      TotalCost : 6
      };
     
     http.post.and.returnValues(of(_product));
   
      service.AddProductService(_product).subscribe((result : true )=>
      {  
         expect(result).toEqual(true);
      });


  });

});
