import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StoreService {

  storageArray :   string[] = [];
  constructor() { }

  addToArray(input: string)
  {
    this.storageArray.push(input);
  }

  getFromArray()
  {
    return this.storageArray;
  }
}
