import { TestBed } from '@angular/core/testing';

import { StoreService } from './store.service';

describe('StoreService', () => {
  let service: StoreService;

  beforeEach(() => {   
    service = new StoreService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should Added one item', () => {
    service.addToArray('check')
    expect(service.getFromArray().length).toEqual(1);
  });
});
