import { Component, OnInit   } from '@angular/core';
import { from } from 'rxjs';
import { NamePipe } from './shared/pipes/name.pipe';
import { Product, ProductService } from './shared/services/product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  

  productList : Product[];  
  title = 'AngularUnitTest';

  constructor(private _ProductService : ProductService)
  {

  }

  ngOnInit(): void {
    debugger;
    this._ProductService.GetProductService().subscribe((data:Product[])=>
    {      
      this.productList = data;
    });
  }



}
