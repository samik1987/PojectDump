import { HttpClient } from '@angular/common/http';
import { TestBed, async , ComponentFixture, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { browser, By } from 'protractor';
import { of } from 'rxjs';
import { AppComponent } from './app.component';
import { Product, ProductService } from './shared/services/product.service';

fdescribe('AppComponent', () => {
  
  let http: jasmine.SpyObj<HttpClient>;
  let service: ProductService;
  let data : Product[];
  let fixture : ComponentFixture<AppComponent>;
  
  beforeEach(() => {
    
    http = jasmine.createSpyObj('HttpClient',['get','post']);
   
    TestBed.configureTestingModule({
      declarations :[AppComponent],
      providers: [
        ProductService,
        {
          provide:HttpClient ,useValue : http
        }
      ]
    });
    service = TestBed.inject(ProductService);
    fixture = TestBed.createComponent(AppComponent);
   
  });

  it('should create the AppComponent', () => {   
    expect(fixture.componentInstance).toBeTruthy();
  });

  it('should Data Received AppComponent', () => {
    let http: jasmine.SpyObj<HttpClient>;
    let service: ProductService;
    let data : Product[];
  
    const _products : Product[] = [
      {
      Id : 1 ,
      Title : "Cycle",
      Cost : 2,
      Quantity : 3,
      TotalCost : 6
      },
      {
        Id : 2 ,
        Title : "Truck",
        Cost : 2,
        Quantity : 4,
        TotalCost : 8
        },
      
  ];
      http.get.and.returnValues(of(_products));
   
      service.GetProductService().subscribe((result : Product[] )=>
      {  
         fixture.detectChanges();
         
         fakeAsync(() => {
         expect(result.length).toEqual(fixture.componentInstance.productList.length);
         });
         
      });
  });
 
 
});
