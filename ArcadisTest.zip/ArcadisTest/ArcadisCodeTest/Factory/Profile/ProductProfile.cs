﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper.Mappers;
using AutoMapper;
using Factory.DTO;
using ArcadisCodeTest.Entity.Model;

namespace Factory
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<ProductDTO, ProductModel>();
            CreateMap<ProductModel, ProductDTO>();


            /*etc...*/
        }
    }
}
