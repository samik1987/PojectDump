﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Repository.Transaction;
using ArcadisCodeTest.Entity.Model;
using Factory.DTO;

namespace Factory.Controller
{
    public class GeneralProduct : IFactory
    {
        public List<ProductModel> GetAllProducts()
        {
           return Transaction.GetAllGeneralProducts();
        }

        public ProductModel GetProductById(int productId)
        {
            return Transaction.GetGeneralProductById(productId);
        }

        public bool AddProduct(ProductModel product)
        {
            return Transaction.AddGeneralProduct(product);
        }

        public bool UpdateProduct(ProductModel editedProduct)
        {
            return Transaction.UpdateGeneralProduct(editedProduct);
        }

        public bool DeleteProduct(int productId)
        {
            return Transaction.DeleteGeneralProduct(productId);
        }
    }
}
