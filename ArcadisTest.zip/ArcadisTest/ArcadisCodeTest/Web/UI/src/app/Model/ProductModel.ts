export  class ProductModel {

        public Id : number ;
        public Title : string;
        public Cost : number;
        public Quantity : number;
        public TotalCost : number;

 }