import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/Service/product.service';
import { ProductModel } from 'src/app/Model/ProductModel';
import { FormsModule } from '@angular/forms';
import { Validators, FormBuilder, FormGroup, FormControl , ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

    editField: string;
    personList: Array<any>;

    public productList: ProductModel[];
    public productInput : ProductModel = new ProductModel();
    private totalCost : any = 0;
    IsValid : boolean = false;

    productFormGroup : FormGroup;

    

  constructor(private productService: ProductService) {
    
   }

  ngOnInit(): void {   
    this.LoadProducts();
  }

  LoadProducts()
  {
    this.productService.GetProductService().subscribe((data : ProductModel[] )=>{
      //console.log(data);
      this.productList = data;
      //console.log("product list :",this.productList);
    });
  }

  AddProduct()
  {
    this.productService.AddProductService(this.productInput).subscribe((data)=>{
      //console.log("Add Product Response",data);
      this.LoadProducts();
    });

    // Clear Form
    this.productInput = new ProductModel();
    
  }

  

    updateList(id: number, property: string, event: any) {
     
 
      const editField = event.target.textContent;
      if( this.productList[id][property] != editField)
      {     
      
        
        // Take a Update Call Due to  Value Difference
        this.productList[id][property] = editField;

        this.Calculation(id,property);

        const editedProduct : ProductModel
        = {
          Title : this.productList[id]["Title"],
          Id : this.productList[id]["Id"],
          Cost : this.productList[id]["Cost"],
          Quantity : this.productList[id]["Quantity"],
          TotalCost :this.productList[id]["TotalCost"]

        };

        

        this.productService.UpdateProductService(editedProduct).subscribe((data)=>{
          //console.log("Updated Product Response",data);
          this.LoadProducts();
        });

        

        

      }
    }

    remove(id: number) {
      this.productService.DeleteProductService(id).subscribe((data)=>{
        //console.log("Delete Product Response",data);
        this.LoadProducts();
      });
      
    }

  

    changeValue(id: number, property: string, event: any) {
      this.editField = event.target.textContent;
 
      
    }

    Calculation(id: number = -1, property: string)
    {
      try{

       if(id==-1)
       {   
        
        if (isFinite((this.productInput.Cost * this.productInput.Quantity)))
        {
            this.IsValid = true;
            this.totalCost = this.productInput.Cost * this.productInput.Quantity ;
            this.productInput.TotalCost = this.totalCost;
         }
       }
       else
       {
        //console.log("--id--",id);
         //console.log("cost",this.productList[id]["Cost"]);
         //console.log("Quantity",this.productList[id]["Quantity"]);
         if (isFinite((this.productList[id]["Cost"] * this.productList[id]["Quantity"])))
         {
           this.IsValid = false;
           this.productList[id]["TotalCost"] = this.productList[id]["Cost"] * this.productList[id]["Quantity"];
         }
       }

      }
      catch (error)
      {
        alert("Please input correct format!");
      }
    }

}
