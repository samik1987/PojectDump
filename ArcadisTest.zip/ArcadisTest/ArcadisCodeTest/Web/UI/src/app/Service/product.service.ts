import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { ProductModel } from '../Model/ProductModel';
import {  throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private _httpClient : HttpClient;

  BASE_URL : string = "http://localhost:6813/api/";
  
  
  constructor(private httpClient: HttpClient) {   
  
    
     }

     GetProductService()
     {
      return this.httpClient.get( this.BASE_URL +'Products/GetAllGeneralProducts').pipe(catchError(this.handleError));
     }

     AddProductService(_input:ProductModel)
     {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          
        })
      }
      return this.httpClient.post<any>( this.BASE_URL +'Products/AddGeneralProduct', _input,httpOptions).pipe(catchError(this.handleError));
     }

     UpdateProductService(_input:ProductModel)
     {
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          
        })
      }
      return this.httpClient.post<any>( this.BASE_URL +'Products/UpdateGeneralProduct', _input,httpOptions).pipe(catchError(this.handleError));
     }

     DeleteProductService(id:number)
     {

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          'id':id.toString()        
        })
        
      }

      const  params = new  HttpParams().set('pid', id.toString());
      
      return this.httpClient.post<any>( this.BASE_URL +'Products/RemoveGeneralProduct',null, { params }).pipe(catchError(this.handleError));

     }

     handleError(error: HttpErrorResponse) {
      let errorMessage = 'Unknown error!';
      if (error.error instanceof ErrorEvent) {
        // Client-side errors
        errorMessage = `Error: ${error.error.message}`;
      } else {
        // Server-side errors
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
      window.alert(errorMessage);
      return throwError(errorMessage);
    }

     
}
