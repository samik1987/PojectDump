import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './View/dashboard/dashboard.component';
import { HomeComponent } from './view/home/home.component';


const routes: Routes = [
  { path:  'dashboard', component:  DashboardComponent},
  { path:  '**',pathMatch: 'prefix', component:  DashboardComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
