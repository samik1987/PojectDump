﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Transaction
{
    public static partial class Transaction
    {
        public static void Write(Exception ex)
        {
            //Here to place where You can write to Log in DB , File , Event Log

        }
    }
}
