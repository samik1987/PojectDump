﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using ArcadisCodeTest.Entity.Model;
using System.Configuration;

namespace Repository.Transaction
{
    public static partial class Transaction
    {
        private static string sqlConnectionString = ConfigurationManager.AppSettings["DBConn"].ToString();
        public static List<ProductModel> GetAllGeneralProducts()
        {
            List<ProductModel> products = new List<ProductModel>();
            using (IDbConnection connection = new SqlConnection(sqlConnectionString))
            {
                connection.Open();
                products = connection.Query<ProductModel>("Select Id, Title, Cost , Quantity , TotalCost from Product").ToList();
                connection.Close();
            }
            return products;
        }

        public static ProductModel GetGeneralProductById(int productId)
        {
            ProductModel product = new ProductModel();
            using (IDbConnection connection = new SqlConnection(sqlConnectionString))
            {
                connection.Open();
                product = connection.Query<ProductModel>("Select Id, Title, Cost , Quantity , TotalCost from Product  WHERE Id = @Id”").FirstOrDefault();
                connection.Close();
            }
            return product;
        }

        public static bool AddGeneralProduct(ProductModel product)
        {
            try
            {
                using (var connection = new SqlConnection(sqlConnectionString))
                {

                    connection.Open();
                    var affectedRows = connection.Execute("Insert into Product (Title, Cost , Quantity , TotalCost) values (@Title, @Cost , @Quantity , @TotalCost)",
                        new { Title = product.Title, Cost = product.Cost, Quantity = product.Quantity, TotalCost = product.TotalCost });
                    connection.Close();

                    if (affectedRows > 0)
                        return true;
                    else
                        return false;

                }

            }
            catch
            {
                return false;
            }
        }

        public static bool UpdateGeneralProduct(ProductModel editedProduct)
        {
            try
            {
                using (var connection = new SqlConnection(sqlConnectionString))
                {
                    connection.Open();
                    var affectedRows = connection.Execute("Update Product set Title = @Title, Cost=@Cost , Quantity= @Quantity , TotalCost = @TotalCost Where Id = @Id", new { Id = editedProduct.Id, Title = editedProduct.Title, Cost = editedProduct.Cost, Quantity = editedProduct.Quantity, TotalCost = editedProduct.TotalCost });
                    connection.Close();

                    if (affectedRows > 0)
                        return true;
                    else
                        return false;
                }
            }
            catch
            {
                return false;
            }
        }
      

        public static bool DeleteGeneralProduct(int productId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(sqlConnectionString))
                {
                    connection.Open();
                    var affectedRows = connection.Execute("Delete from Product Where Id = @Id", new { Id = productId });
                    connection.Close();

                    if (affectedRows > 0)
                        return true;
                    else
                        return false;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
