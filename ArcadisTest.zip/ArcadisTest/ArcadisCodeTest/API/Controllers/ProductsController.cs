﻿
using ArcadisCodeTest.Entity.Model;
using AutoMapper;
using Factory;
using Factory.Controller;
using Factory.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace API.Controllers
{

    public class ProductsController : ApiController
    {
        private IProductFactory _productFactory;
        private IMapper _mapper;
        private ILogger _logger;

        public ProductsController(IProductFactory productFactory, IMapper mapper, ILogger logger)
        {
            _productFactory = productFactory;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        public IHttpActionResult GetAllGeneralProducts()
        {
            try
            {
                IFactory ifact = _productFactory.GetProduct("general");
                List<ProductDTO> result = _mapper.Map<List<ProductModel>, List<ProductDTO>>(ifact.GetAllProducts());

                return Ok(result.OrderBy(x => x.Id).ToList());
            }
            catch (Exception ex)
            {
                _logger.Write(ex);
                return NotFound();

            }

        }

        [HttpPost]
        public IHttpActionResult AddGeneralProduct(ProductDTO inputProduct)
        {
            try
            {
                IFactory ifact = _productFactory.GetProduct("general");
                bool result = ifact.AddProduct(_mapper.Map<ProductDTO, ProductModel>(inputProduct));

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Write(ex);
                return NotFound();
            }

        }

        [HttpPost]
        public IHttpActionResult UpdateGeneralProduct(ProductDTO inputProduct)
        {
            try
            {
                IFactory ifact = _productFactory.GetProduct("general");
                bool result = ifact.UpdateProduct(_mapper.Map<ProductDTO, ProductModel>(inputProduct));

                return Ok(result);

            }
            catch (Exception ex)
            {
                _logger.Write(ex);
                return NotFound();
            }

        }

        [HttpPost]
        public IHttpActionResult RemoveGeneralProduct(int pid)
        {
            try
            {
                IFactory ifact = _productFactory.GetProduct("general");
                bool result = ifact.DeleteProduct(pid);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.Write(ex);
                return NotFound();
            }

        }

    }
}
